package nasoram.unal.edu.co.companiesmanagement.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import nasoram.unal.edu.co.companiesmanagement.R;
import nasoram.unal.edu.co.companiesmanagement.model.Company;
import nasoram.unal.edu.co.companiesmanagement.sqlite.SQLiteCompanyOperations;

public class AddUpdateCompanyActivity extends AppCompatActivity {

    private static final String EXTRA_COMP_ID = "company_id";
    private static final String EXTRA_ADD_UPDATE = "add_update";

    private EditText nameEditText;
    private EditText urlEditText;
    private EditText phoneEditText;
    private EditText emailEditText;
    private EditText productsEditText;
    private CheckBox consultingCheckBox;
    private CheckBox developmentCheckBox;
    private CheckBox factoryCheckBox;
    private Button addUpdateButton;

    private Company oldCompany;
    private Company newCompany;

    private String mode;

    private SQLiteCompanyOperations sqlOps;
    private long companyId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_update_company);

        nameEditText = (EditText) findViewById(R.id.edit_text_name);
        urlEditText = (EditText) findViewById(R.id.edit_text_url);
        phoneEditText = (EditText) findViewById(R.id.edit_text_phone);
        emailEditText = (EditText) findViewById(R.id.edit_text_email);
        productsEditText = (EditText) findViewById(R.id.editText_products);
        consultingCheckBox = (CheckBox) findViewById(R.id.consultingCheckBox);
        developmentCheckBox = (CheckBox) findViewById(R.id.developmentCheckBox);
        factoryCheckBox = (CheckBox) findViewById(R.id.software_factoryCheckBox);
        addUpdateButton = (Button) findViewById(R.id.button_add_update_company);

        oldCompany = new Company();
        newCompany = new Company();

        sqlOps = new SQLiteCompanyOperations(this);
        sqlOps.open();

        mode = getIntent().getStringExtra(EXTRA_ADD_UPDATE);
        if (mode.equals("Update")){

            addUpdateButton.setText(R.string.update_company);
            companyId = getIntent().getLongExtra(EXTRA_COMP_ID, 0);
            System.out.println("NAME=" + sqlOps.getCompany(companyId).getCompanyName());
            System.out.println("URL=" + sqlOps.getCompany(companyId).getWebUrl());

            initializeCompany(companyId);
        }

        addUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mode.equals("Add")) {
                    newCompany.setCompanyName(nameEditText.getText().toString());
                    newCompany.setWebUrl(urlEditText.getText().toString());
                    newCompany.setPhone(phoneEditText.getText().toString());
                    newCompany.setEmail(emailEditText.getText().toString());
                    newCompany.setProducts(productsEditText.getText().toString());
                    newCompany.setConsultancy(consultingCheckBox.isChecked() ? 1 : 0);
                    newCompany.setDevelopment(developmentCheckBox.isChecked() ? 1 : 0);
                    newCompany.setFactory(factoryCheckBox.isChecked() ? 1 : 0);
                    sqlOps.addCompany(newCompany);
                    Toast t = Toast.makeText(AddUpdateCompanyActivity.this, "Company " + newCompany.getCompanyName() + " has been added successfully !", Toast.LENGTH_LONG);
                    t.show();
                    Intent i = new Intent(AddUpdateCompanyActivity.this, MainActivity.class);
                    startActivity(i);
                } else {
                    oldCompany.setCompanyName(nameEditText.getText().toString());
                    oldCompany.setWebUrl(urlEditText.getText().toString());
                    oldCompany.setPhone(phoneEditText.getText().toString());
                    oldCompany.setEmail(emailEditText.getText().toString());
                    oldCompany.setProducts(productsEditText.getText().toString());
                    oldCompany.setConsultancy(consultingCheckBox.isChecked() ? 1 : 0);
                    oldCompany.setDevelopment(developmentCheckBox.isChecked() ? 1 : 0);
                    oldCompany.setFactory(factoryCheckBox.isChecked() ? 1 : 0);
                    sqlOps.updateCompany(oldCompany);
                    Toast t = Toast.makeText(AddUpdateCompanyActivity.this, "Company " + oldCompany.getCompanyName() + " has been updated successfully !", Toast.LENGTH_LONG);
                    t.show();
                    Intent i = new Intent(AddUpdateCompanyActivity.this, MainActivity.class);
                    startActivity(i);
                }
            }
        });

    }

    /*public void onCheckboxClicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();

        switch(view.getId()) {
            case R.id.consultingCheckBox:
                if (checked)
                    consulting = 1;
                else consulting = 0;
                break;
            case R.id.developmentCheckBox:
                if (checked)
                    development = 1;
                else development = 0;
                break;
            case R.id.software_factoryCheckBox:
                if (checked)
                    factory = 1;
                else factory = 0;
                break;
        }
    }*/

    private void initializeCompany(long companyId) {
        oldCompany = sqlOps.getCompany(companyId);
        nameEditText.setText(oldCompany.getCompanyName());
        urlEditText.setText(oldCompany.getWebUrl());
        phoneEditText.setText(oldCompany.getPhone());
        emailEditText.setText(oldCompany.getEmail());
        productsEditText.setText(oldCompany.getProducts());
        consultingCheckBox.setChecked(oldCompany.getConsultancy() == 1);
        developmentCheckBox.setChecked(oldCompany.getDevelopment() == 1);
        factoryCheckBox.setChecked(oldCompany.getFactory() == 1);
    }

}
