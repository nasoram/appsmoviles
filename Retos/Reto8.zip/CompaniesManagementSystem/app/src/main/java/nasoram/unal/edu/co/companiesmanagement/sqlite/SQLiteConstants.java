package nasoram.unal.edu.co.companiesmanagement.sqlite;

/**
 * Created by Nelson Sora on 12/11/2017.
 */

public class SQLiteConstants {

    public static final String T_COMPANIES = "companies";
    public static final String COLUMN_ID = "companyId";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_URL = "url";
    public static final String COLUMN_PHONE = "phone";
    public static final String COLUMN_EMAIL= "email";
    public static final String COLUMN_PRODUCTS = "products";
    public static final String COLUMN_CONSULTANCY = "consultancy";
    public static final String COLUMN_DEVELOPMENT = "development";
    public static final String COLUMN_FACTORY = "factory";

    public static final String CREATE_TABLE_COMPANIES = "CREATE TABLE " + T_COMPANIES + "(" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_NAME + " TEXT, " +
            COLUMN_URL + " TEXT, " +
            COLUMN_PHONE + " TEXT, " +
            COLUMN_EMAIL + " TEXT, " +
            COLUMN_PRODUCTS + " TEXT, " +
            COLUMN_CONSULTANCY + " NUMERIC, " +
            COLUMN_DEVELOPMENT + " NUMERIC, " +
            COLUMN_FACTORY + " NUMERIC" +
            ")";

    public static final String DROP_TABLE_COMPANIES = "DROP TABLE IF EXISTS " + T_COMPANIES;

    public static final String[] ALL_COLUMNS = {
            COLUMN_ID,
            COLUMN_NAME,
            COLUMN_URL,
            COLUMN_PHONE,
            COLUMN_EMAIL,
            COLUMN_PRODUCTS,
            COLUMN_CONSULTANCY,
            COLUMN_DEVELOPMENT,
            COLUMN_FACTORY
    };

}
