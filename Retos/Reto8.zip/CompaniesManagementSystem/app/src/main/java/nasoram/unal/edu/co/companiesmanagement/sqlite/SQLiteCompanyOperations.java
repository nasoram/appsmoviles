package nasoram.unal.edu.co.companiesmanagement.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import nasoram.unal.edu.co.companiesmanagement.model.Company;

/**
 * Created by Nelson Sora on 12/11/2017.
 */

public class SQLiteCompanyOperations {

    public static final String TAG = "COMPANIES_MNGMNT";

    SQLiteOpenHelper dbhandler;
    SQLiteDatabase database;

    public SQLiteCompanyOperations(Context context) {
        dbhandler = new SQLiteHelper(context);
    }

    public void open(){
        Log.i(TAG,"Database Opened");
        database = dbhandler.getWritableDatabase();
    }
    
    public void close(){
        Log.i(TAG, "Database Closed");
        dbhandler.close();
    }
    
    public Company addCompany(Company company){
        ContentValues values  = new ContentValues();
        values.put(SQLiteConstants.COLUMN_NAME, company.getCompanyName());
        values.put(SQLiteConstants.COLUMN_URL, company.getWebUrl());
        values.put(SQLiteConstants.COLUMN_PHONE, company.getPhone());
        values.put(SQLiteConstants.COLUMN_EMAIL, company.getEmail());
        values.put(SQLiteConstants.COLUMN_PRODUCTS, company.getProducts());
        values.put(SQLiteConstants.COLUMN_CONSULTANCY, company.getConsultancy());
        values.put(SQLiteConstants.COLUMN_DEVELOPMENT, company.getDevelopment());
        values.put(SQLiteConstants.COLUMN_FACTORY, company.getFactory());
        long insertId = dbhandler.getWritableDatabase().insert(SQLiteConstants.T_COMPANIES, null, values);
        company.setId(insertId);
        return company;

    }

    // Getting single company
    public Company getCompany(long id) {

        String query = "SELECT * FROM " + SQLiteConstants.T_COMPANIES +
                " WHERE " + SQLiteConstants.COLUMN_ID + " = " + id;

        Cursor cursor = dbhandler.getWritableDatabase().rawQuery(query, null);
        if (cursor != null)
            cursor.moveToFirst();

        Company c = new Company(Long.parseLong(cursor.getString(0)),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3),
                cursor.getString(4),
                cursor.getString(5),
                Integer.parseInt(cursor.getString(6)),
                Integer.parseInt(cursor.getString(7)),
                Integer.parseInt(cursor.getString(8)));
        // return Company
        return c;
    }

    public String getCompanyName(long id) {

        String query = "SELECT " + SQLiteConstants.COLUMN_NAME + " FROM " + SQLiteConstants.T_COMPANIES +
                " WHERE " + SQLiteConstants.COLUMN_ID + " = " + id;

        Cursor cursor = dbhandler.getWritableDatabase().rawQuery(query, null);
        if (cursor != null)
            cursor.moveToFirst();

        return cursor.getString(0);
    }

    public String getCompanyWebUrl(long id) {

        String query = "SELECT " + SQLiteConstants.COLUMN_URL + " FROM " + SQLiteConstants.T_COMPANIES +
                " WHERE " + SQLiteConstants.COLUMN_ID + " = " + id;

        Cursor cursor = dbhandler.getWritableDatabase().rawQuery(query, null);
        if (cursor != null)
            cursor.moveToFirst();

        return cursor.getString(0);
    }

    public long getIdbyName(String name) {

        String query = "SELECT " + SQLiteConstants.COLUMN_ID + " FROM " + SQLiteConstants.T_COMPANIES +
                " WHERE " + SQLiteConstants.COLUMN_NAME + " = \"" + name +
                "\" ORDER BY " + SQLiteConstants.COLUMN_ID + " ASC LIMIT 1";
        Cursor cursor = dbhandler.getWritableDatabase().rawQuery(query, null);
        if (cursor != null)
            cursor.moveToFirst();

        return Long.parseLong(cursor.getString(0));
    }

    public List<Company> getAllCompanies() {

        Cursor cursor = dbhandler.getWritableDatabase().query(SQLiteConstants.T_COMPANIES, SQLiteConstants.ALL_COLUMNS,
                null, null, null, null, null);

        List<Company> companies = new ArrayList<>();
        if(cursor.getCount() > 0) {
            while(cursor.moveToNext()) {
                Company company = new Company();
                company.setId(cursor.getLong(cursor.getColumnIndex(SQLiteConstants.COLUMN_ID)));
                company.setCompanyName(cursor.getString(cursor.getColumnIndex(SQLiteConstants.COLUMN_URL)));
                company.setPhone(cursor.getString(cursor.getColumnIndex(SQLiteConstants.COLUMN_PHONE)));
                company.setEmail(cursor.getString(cursor.getColumnIndex(SQLiteConstants.COLUMN_EMAIL)));
                company.setProducts(cursor.getString(cursor.getColumnIndex(SQLiteConstants.COLUMN_PRODUCTS)));
                company.setConsultancy(cursor.getInt(cursor.getColumnIndex(SQLiteConstants.COLUMN_CONSULTANCY)));
                company.setDevelopment(cursor.getInt(cursor.getColumnIndex(SQLiteConstants.COLUMN_DEVELOPMENT)));
                company.setFactory(cursor.getInt(cursor.getColumnIndex(SQLiteConstants.COLUMN_FACTORY)));
                companies.add(company);
            }
        }
        // return All Companies
        return companies;
    }

    // Updating Company
    public int updateCompany(Company company) {

        ContentValues values = new ContentValues();
        values.put(SQLiteConstants.COLUMN_NAME, company.getCompanyName());
        values.put(SQLiteConstants.COLUMN_URL, company.getWebUrl());
        values.put(SQLiteConstants.COLUMN_PHONE, company.getPhone());
        values.put(SQLiteConstants.COLUMN_EMAIL, company.getEmail());
        values.put(SQLiteConstants.COLUMN_PRODUCTS, company.getProducts());
        values.put(SQLiteConstants.COLUMN_CONSULTANCY, company.getConsultancy());
        values.put(SQLiteConstants.COLUMN_DEVELOPMENT, company.getDevelopment());
        values.put(SQLiteConstants.COLUMN_FACTORY, company.getFactory());

        // updating row
        return dbhandler.getWritableDatabase().update(SQLiteConstants.T_COMPANIES, values,
                SQLiteConstants.COLUMN_ID + "=?", new String[] { String.valueOf(company.getId())});
    }

    // Deleting Company
    public void removeCompany(Company company) {

        dbhandler.getWritableDatabase().delete(SQLiteConstants.T_COMPANIES, SQLiteConstants.COLUMN_ID + "=" + company.getId(), null);
    }
}
