package nasoram.unal.edu.co.companiesmanagement.activities;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import nasoram.unal.edu.co.companiesmanagement.R;
import nasoram.unal.edu.co.companiesmanagement.model.Company;
import nasoram.unal.edu.co.companiesmanagement.sqlite.SQLiteCompanyOperations;

public class ViewAllCompaniesActivity extends AppCompatActivity {

    private static final int DELETE_DEFINITELY = 100;
    private static final String EXTRA_COMP_ID = "company_id";
    private static final String EXTRA_ADD_UPDATE = "add_update";
    long updateId;
    long deleteId;

    private LinearLayout container;
    private SQLiteCompanyOperations sqlOps;
    private List<Company> companies;
    private TextView companyInfoTextView;
    private FloatingActionButton editCompanyFab;
    private FloatingActionButton deleteCompanyFab;
    private TextView companyNameTextView;
    private FloatingActionButton addCompanyFab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_companies);

        container = (LinearLayout) findViewById(R.id.container);
        addCompanyFab = (FloatingActionButton) findViewById(R.id.add_fab);
        addCompanyFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ViewAllCompaniesActivity.this, AddUpdateCompanyActivity.class);
                i.putExtra(EXTRA_ADD_UPDATE, "Add");
                startActivity(i);
            }
        });

        sqlOps = new SQLiteCompanyOperations(this);
        sqlOps.open();
        companies = sqlOps.getAllCompanies();

        loadCompanies();

    }

    private void loadCompanies() {
        container.removeAllViews();

        LayoutInflater layoutInflater =
                (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        for (int i = 0; i < companies.size(); i++) {
            final View newCompanyCardView = layoutInflater.inflate(R.layout.new_company_card, null);
            editCompanyFab = (FloatingActionButton) newCompanyCardView.findViewById(R.id.editFab);
            deleteCompanyFab = (FloatingActionButton) newCompanyCardView.findViewById(R.id.deleteFab);
            companyNameTextView = (TextView) newCompanyCardView.findViewById(R.id.company_name_title);
            companyInfoTextView = (TextView) newCompanyCardView.findViewById(R.id.company_Info);
            companyNameTextView.setText(sqlOps.getCompanyName(companies.get(i).getId()) + " - [" + companies.get(i).getId() + "]");
            String result = "Web URL: " + sqlOps.getCompanyWebUrl(companies.get(i).getId()) +
                    "\nPhone: " + companies.get(i).getPhone() +
                    "\nE-mail: " + companies.get(i).getEmail() +
                    "\nProducts/Services:\n" + companies.get(i).getProducts() +
                    "\nLabels:";

            if (companies.get(i).getConsultancy() == 1) result += "\n\uFFED Consultancy";
            if (companies.get(i).getDevelopment() == 1) result += "\n\uFFED Development";
            if (companies.get(i).getFactory() == 1) result += "\n\uFFED Software Factory";
            companyInfoTextView.setText(result);

            updateId = companies.get(i).getId();
            deleteId = companies.get(i).getId();
            editCompanyFab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(ViewAllCompaniesActivity.this, AddUpdateCompanyActivity.class);
                    i.putExtra(EXTRA_ADD_UPDATE, "Update");
                    i.putExtra(EXTRA_COMP_ID, updateId);
                    startActivity(i);
                }
            });

            deleteCompanyFab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showDialog(DELETE_DEFINITELY);
                }
            });

            container.addView(newCompanyCardView);
        }

    }

    @Override
    public Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // Show an about dialog box
        Context context = getApplicationContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);

        switch(id) {
            case DELETE_DEFINITELY:
                builder.setTitle(R.string.confirm_delete)
                        .setMessage("Do you really want to delete this Company?")
                        .setCancelable(false)
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                sqlOps = new SQLiteCompanyOperations(ViewAllCompaniesActivity.this);
                                sqlOps.removeCompany(sqlOps.getCompany(deleteId));
                                Toast t = Toast.makeText(ViewAllCompaniesActivity.this,"Company removed successfully!", Toast.LENGTH_SHORT);
                                t.show();
                                Intent i = new Intent(ViewAllCompaniesActivity.this, MainActivity.class);
                                startActivity(i);
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create()
                        .show();
                break;
        }

        return dialog;
    }
}
