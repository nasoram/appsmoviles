package nasoram.unal.edu.co.companiesmanagement.activities;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import nasoram.unal.edu.co.companiesmanagement.R;
import nasoram.unal.edu.co.companiesmanagement.sqlite.SQLiteCompanyOperations;

public class MainActivity extends AppCompatActivity {

    private static final int SELECT_INPUT = 1;
    private static final int GET_COMPANY_ID = 5;
    private static final int GET_COMPANY_NAME = 10;
    private static final int SELECT_DELETE = 20;
    private static final int DELETE_COMPANY_ID = 25;
    private static final int DELETE_COMPANY_NAME = 30;
    private static final int DELETE_DEFINITELY = 100;
    private Button addCompanyButton;
    private Button updateCompanyButton;
    private Button removeCompanyButton;
    private Button viewAllCompaniesButton;
    private SQLiteCompanyOperations sqlOps;
    private static final String EXTRA_COMP_ID = "company_id";
    private static final String EXTRA_ADD_UPDATE = "add_update";
    long deleteId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addCompanyButton = (Button) findViewById(R.id.button_add);
        updateCompanyButton = (Button) findViewById(R.id.button_update);
        removeCompanyButton = (Button) findViewById(R.id.button_remove);
        viewAllCompaniesButton = (Button) findViewById(R.id.button_view_all);

        sqlOps = new SQLiteCompanyOperations(this);

        addCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, AddUpdateCompanyActivity.class);
                i.putExtra(EXTRA_ADD_UPDATE, "Add");
                startActivity(i);
            }
        });

        updateCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(SELECT_INPUT);
            }
        });

        removeCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(SELECT_DELETE);
            }
        });

        viewAllCompaniesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, ViewAllCompaniesActivity.class);
                startActivity(i);
            }
        });
    }

    @Override
    public Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // Show an about dialog box
        Context context = getApplicationContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);

        switch (id) {
            case SELECT_INPUT:
                builder.setTitle(R.string.search_by)
                        .setItems(R.array.search_array, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == 0) {
                                    showDialog(GET_COMPANY_ID);
                                } else {
                                    showDialog(GET_COMPANY_NAME);
                                }
                            }
                        }).create()
                        .show();

                break;
            case GET_COMPANY_ID:
                View getCompIdView = inflater.inflate(R.layout.dialog_get_company, null);
                builder.setView(getCompIdView);
                final EditText userInput = (EditText) getCompIdView.findViewById(R.id.editTextDialogUserInput);
                // set dialog message
                builder.setTitle(R.string.id_search_title)
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(MainActivity.this, AddUpdateCompanyActivity.class);
                                i.putExtra(EXTRA_ADD_UPDATE, "Update");
                                i.putExtra(EXTRA_COMP_ID, Long.parseLong(userInput.getText().toString()));
                                startActivity(i);
                            }
                        }).create()
                        .show();
                break;
            case GET_COMPANY_NAME:
                View getCompNameView = inflater.inflate(R.layout.dialog_get_company, null);
                builder.setView(getCompNameView);
                final EditText userInp = (EditText) getCompNameView.findViewById(R.id.editTextDialogUserInput);
                // set dialog message
                builder.setTitle(R.string.name_search_title)
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(MainActivity.this, AddUpdateCompanyActivity.class);
                                i.putExtra(EXTRA_ADD_UPDATE, "Update");
                                i.putExtra(EXTRA_COMP_ID, sqlOps.getIdbyName(userInp.getText().toString()));
                                startActivity(i);
                            }
                        }).create()
                        .show();
                break;
            case SELECT_DELETE:
                builder.setTitle(R.string.search_by)
                        .setItems(R.array.search_array, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == 0) {
                                    showDialog(DELETE_COMPANY_ID);
                                } else {
                                    showDialog(DELETE_COMPANY_NAME);
                                }
                            }
                        }).create()
                        .show();

                break;
            case DELETE_COMPANY_ID:
                View delCompIdView = inflater.inflate(R.layout.dialog_get_company, null);
                builder.setView(delCompIdView);
                final EditText usrInput = (EditText) delCompIdView.findViewById(R.id.editTextDialogUserInput);
                // set dialog message
                builder.setTitle(R.string.id_search_title)
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                deleteId = Long.parseLong(usrInput.getText().toString());
                                showDialog(DELETE_DEFINITELY);
                            }
                        }).create()
                        .show();
                break;
            case DELETE_COMPANY_NAME:
                View delCompNameView = inflater.inflate(R.layout.dialog_get_company, null);
                builder.setView(delCompNameView);
                final EditText usrInp = (EditText) delCompNameView.findViewById(R.id.editTextDialogUserInput);
                // set dialog message
                builder.setTitle(R.string.name_search_title)
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                deleteId = sqlOps.getIdbyName(usrInp.getText().toString());
                                showDialog(DELETE_DEFINITELY);
                            }
                        }).create()
                        .show();
                break;
            case DELETE_DEFINITELY:
                builder.setTitle(R.string.confirm_delete)
                        .setMessage("Do you really want to delete this Company?")
                        .setCancelable(false)
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                sqlOps = new SQLiteCompanyOperations(MainActivity.this);
                                sqlOps.removeCompany(sqlOps.getCompany(deleteId));
                                Toast t = Toast.makeText(MainActivity.this, "Company removed successfully!", Toast.LENGTH_SHORT);
                                t.show();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create()
                        .show();
                break;
        }

        return dialog;
    }

    @Override
    protected void onResume() {
        super.onResume();
        sqlOps.open();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sqlOps.close();

    }

}
