package nasoram.unal.edu.co.companiesmanagement.model;

/**
 * Created by Nelson Sora on 12/11/2017.
 */

public class Company {

    private long id;
    private String companyName;
    private String webUrl;
    private String phone;
    private String email;
    private String products;
    private int consultancy;
    private int development;
    private int factory;

    public Company() {
    }

    public Company(long id, String companyName, String webUrl, String phone, String email, String products, int consultancy, int development, int factory) {
        this.id = id;
        this.companyName = companyName;
        this.webUrl = webUrl;
        this.phone = phone;
        this.email = email;
        this.products = products;
        this.consultancy = consultancy;
        this.development = development;
        this.factory = factory;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProducts() {
        return products;
    }

    public void setProducts(String products) {
        this.products = products;
    }

    public int getConsultancy() {
        return consultancy;
    }

    public void setConsultancy(int consultancy) {
        this.consultancy = consultancy;
    }

    public int getDevelopment() {
        return development;
    }

    public void setDevelopment(int development) {
        this.development = development;
    }

    public int getFactory() {
        return factory;
    }

    public void setFactory(int factory) {
        this.factory = factory;
    }

    @Override
    public String toString() {
        String result = "Company ID: " + id +
                "\nName: " + companyName +
                "Web URL: " + webUrl +
                "\nPhone: " + phone +
                "\nE-mail: " + email +
                "\nProducts/Services:\n" + products +
                "\nLabels:";

        if (this.getConsultancy() == 1) result += "\nConsultancy";
        if (this.getDevelopment() == 1) result += "\nDevelopment";
        if (this.getFactory() == 1) result += "\nSoftware Factory";

        return result;
    }
}
